const fs = require('fs-extra');
const path = require('path');
const { image } = require('image-downloader');
const Jimp = require('jimp');

module.exports.run = async function ({
    api, event, args
}) {
    try {
        var tpk = `🖼️=== [ PHOTO WITH BORDER ] ===🖼️\n━━━━━━━━━━━━━━━\n[⚜️]➜ Created by Nusrat`;
        if (event.type !== "message_reply") return api.sendMessage("[⚜️]➜ You must reply to a photo", event.threadID, event.messageID);
        if (!event.messageReply.attachments || event.messageReply.attachments.length == 0) return api.sendMessage("[⚜️]➜ Created by Nusrat", event.threadID, event.messageID);
        if (event.messageReply.attachments[0].type != "photo") return api.sendMessage("[⚜️]➜ This is not an image", event.threadID, event.messageID);

        const content = (event.type == "message_reply") ? event.messageReply.attachments[0].url : args.join(" ");
        const inputPath = path.resolve(__dirname, 'cache', `photo.png`);
        await image({
            url: content, dest: inputPath
        });

        // Function to add border to the image
        async function addBorderToImage(imagePath) {
            const image = await Jimp.read(imagePath);
            const borderWidth = 100; // Adjust border width as needed
            const maxSize = Math.max(image.bitmap.width, image.bitmap.height);
            const squareCanvas = new Jimp(maxSize, maxSize, 0xFFFF00FF); // Create a square canvas with white background
            const startX = Math.floor((maxSize - image.bitmap.width) / 2); // Calculate the starting X position for pasting the image
            const startY = Math.floor((maxSize - image.bitmap.height) / 2); // Calculate the starting Y position for pasting the image

            // Paste the original image onto the square canvas without cropping
            squareCanvas.composite(image, startX, startY);

            // Add border to the square canvas
            squareCanvas.contain(maxSize + (2 * borderWidth), maxSize + (2 * borderWidth), Jimp.HORIZONTAL_ALIGN_CENTER | Jimp.VERTICAL_ALIGN_MIDDLE);

            return squareCanvas;
        }

        const modifiedImagePath = path.resolve(__dirname, 'cache', `modified_photo.png`);
        await addBorderToImage(inputPath).then(modifiedImage => modifiedImage.writeAsync(modifiedImagePath));

        // Send modified image back to the user
        return api.sendMessage({ body: tpk, attachment: fs.createReadStream(modifiedImagePath) }, event.threadID, () => {
            fs.unlinkSync(inputPath);
            fs.unlinkSync(modifiedImagePath);
        });
    } catch (e) {
        console.log(e)
        return api.sendMessage(`[⚜️]➜ Nayan Server Is Busy Now`, event.threadID, event.messageID);
    }
};

module.exports.config = {
    name: "addborder",
    version: "1.0.0",
    permission: 0,
    credits: "Nayan",
    description: "",
    prefix: true,
    category: "prefix",
    usages: "reply",
    cooldowns: 10,
    dependencies: {
        'image-downloader': '',
        'jimp': ''
    }
};
