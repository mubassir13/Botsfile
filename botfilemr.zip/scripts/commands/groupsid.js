module.exports.config = {
  name: "groupsid",	
  version: "1.0.0", 
	permission: 0,
	credits: "ryuko",
	description: "get box id", 
	prefix: true,
	category: "with prefix",
	usages: "groupid",
	cooldowns: 0, 
	dependencies: '',
};

module.exports.run = async function({ api, event }) {
  api.sendMessage("group id : "+event.threadID, event.threadID, event.messageID);
};